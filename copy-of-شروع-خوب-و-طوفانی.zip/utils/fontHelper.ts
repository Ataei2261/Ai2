// This is a placeholder for font-related helper functions.
// Currently, it's empty but syntactically valid to prevent parsing errors.
export {}; // Ensures it's treated as a module
